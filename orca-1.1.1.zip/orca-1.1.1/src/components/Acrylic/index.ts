export { default } from "./Acrylic";

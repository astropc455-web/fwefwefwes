export const IS_DEV = getgenv === undefined;
export const VERSION_TAG = VERSION ?? "studio";

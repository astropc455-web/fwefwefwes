export { default } from "./FriendActivity";
